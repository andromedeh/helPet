package data.JBDC;

public class VacinaDaoJdbc {

}
